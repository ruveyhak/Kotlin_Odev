package com.example.hesap_makinesi

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var textViewResult: TextView
    private var currentInput = ""
    private var totalSum = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        textViewResult = findViewById(R.id.textViewResult)

        val numberButtons = listOf(
            R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3,
            R.id.btn4, R.id.btn5, R.id.btn6,
            R.id.btn7, R.id.btn8, R.id.btn9
        )

        for (id in numberButtons) {
            findViewById<Button>(id).setOnClickListener {
                val value = (it as Button).text.toString()
                currentInput += value
                textViewResult.text = currentInput
            }
        }

        findViewById<Button>(R.id.btnAdd).setOnClickListener {
            addCurrentInput()
        }

        findViewById<Button>(R.id.btnEqual).setOnClickListener {
            addCurrentInput()
            textViewResult.text = totalSum.toString()
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            currentInput = ""
            totalSum = 0
            textViewResult.text = "0"
        }
    }

    private fun addCurrentInput() {
        if (currentInput.isNotEmpty()) {
            totalSum += currentInput.toInt()
            currentInput = ""
            textViewResult.text = "0"
        }
    }
}
